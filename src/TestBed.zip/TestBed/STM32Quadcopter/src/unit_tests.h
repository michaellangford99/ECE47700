#define TEENSYQUADCOPTER 1
//#define TEST_DEBUG_LED   1
//#define TEST_MPU9250     1
//#define TEST_MPU9250     1
//#define TEST_MOTORS        1